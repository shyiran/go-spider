package url

const (
	ChromeDriver = "/Users/xiewei/Downloads/App/chromedriver"
)
