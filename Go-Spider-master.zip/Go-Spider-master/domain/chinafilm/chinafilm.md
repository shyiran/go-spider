### ChinaFilm

#### 1. 网址

URl = "http://i.chinafilm.com/index/Movie/movielist"


#### 2. Ajax


Method|URL|
---|---|
POST|http://i.chinafilm.com/index/Movie/ajaxList|


![](image/影库.png)

![](image/POSTMAN.png)


