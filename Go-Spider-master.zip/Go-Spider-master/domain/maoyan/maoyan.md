### 猫眼票房排行榜


### 1. 网址

Method|URL|
---|---|
GET|https://piaofang.maoyan.com/rankings/year?year=2018&limit=100&tab=1|




![](image/rank_2018.png)



### 2. 问题

> 页面使用了font-face定义了字符集，并通过unicode去映射展示

[参考链接](http://litten.me/2017/07/09/prevent-spiders/)



### 3. 正则表达式

[正则表达式参考](https://github.com/StefanSchroeder/Golang-Regex-Tutorial)