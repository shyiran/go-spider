### 糯米电影


#### 1. 网址

Method|URL|
---|---|
GET|https://mdianying.baidu.com/rank/index|


#### 2. 分析

Method|URL|Content|Type|
---|---|---|---|
GET|https://mdianying.baidu.com/api/discovery/ranking|票房排行|json|
GET|https://mdianying.baidu.com/api/rank/rankPage|榜单|json|



- gjson 的使用

[参考文档](https://github.com/tidwall/gjson)


![](image/ranking.png)

