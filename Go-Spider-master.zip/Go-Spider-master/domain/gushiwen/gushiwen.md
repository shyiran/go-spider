### 古诗文


#### 1. 网址

Method|URL|
---|---|
GET|https://www.gushiwen.org/shiwen/|


#### 2. 朝代和类型分析

![](image/朝代和类型.png)


### 3. 分析

Method|URL|
---|---|
GET|https://www.gushiwen.org/shiwen/default.aspx?page=1&type=0&id=0|


- totalPage 1000
- 先获取诗，在获取诗人，类型是否有，朝代是否有

![](image/诗文.png)

![](image/诗人.png)

